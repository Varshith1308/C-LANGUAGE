#include<stdio.h>
main()
{
	int num;
    printf("Enter an integer: ");
    scanf("%d", &num);

    
    if(num % 2 == 0)
    {
        printf("num is even");
    }
    if(num %2 != 0)
    {
        printf("num is odd");
    }
    
}
