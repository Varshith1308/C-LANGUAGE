#include<stdio.h>
main()
{
	int a;
	int b;
	int sum;
	printf("Enter a value:");
	scanf("%d",&a);
	printf("Enter b value:");
	scanf("%d",&b);
	sum=a+b;
	printf("the result=%d",sum);
}
