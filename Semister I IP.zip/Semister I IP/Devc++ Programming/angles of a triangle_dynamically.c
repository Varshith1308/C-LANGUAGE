#include<stdio.h>
main()
{
	int a;
	int b;
	int c;
	printf("enter first angle:");
	scanf("%d",&a);
	printf("enter second angle:");
	scanf("%d",&b);
	c=180-(a+b);
	printf("the third angle=%d",c);
}
