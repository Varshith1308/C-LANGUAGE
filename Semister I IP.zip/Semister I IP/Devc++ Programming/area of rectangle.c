#include<stdio.h>
main()
{
	int l=5;
    int b=6;
    int area;
    area=l*b;
    printf("the area=%d",area);
}
