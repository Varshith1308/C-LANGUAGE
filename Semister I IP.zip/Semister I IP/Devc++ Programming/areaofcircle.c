#include<stdio.h>
int main()
{
	float principle,time,rate;
	float SI;
	printf("Enter principle amount: ");
	scanf("%f", &);
	printf("Enter time: ");
	scanf("%f", &time);
	prinf("Enter rate: ");
	scanf("%f", &rate);
    SI=(principle*time*rate)/100;
    printf("simple interest:%f",SI);
    return 0;
}
