#include<stdio.h>
main()
{
	int r;
	float area;
	printf("enter radius:");
	scanf("%d",&r);
	area=(3.14*r*r);
	printf("the result=%f",area);
}
