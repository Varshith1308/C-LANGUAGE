#include<stdio.h>
main()
{
	int a,b,sum,sub;
	printf("enter a:");
	scanf("%d",&a);
	printf("enter b:");
	scanf("%d",&b);
	sum=a+b;
	sub=a-b;
	printf("sum=%d,\nsub=%d",sum,sub);
}
