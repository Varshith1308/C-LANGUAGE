#include<stdio.h>
main()
{
	int a,a1,a2,a3,a4;
	printf("enter a:");
	scanf("%d",&a);
	a1=a/100;
	a2=(a-a1*100)/50;
	a3=(a-(a1*100+a2*50))/20;
	a4=(a-(a1*100+a2*50+a3*20))/2;
	printf("\nno.of 100rs notes=%d,\nno.of 50rs notes=%d,\nno.of 20rs notes=%d,\nno.of 2rs notes=%d",a1,a2,a3,a4);
}
