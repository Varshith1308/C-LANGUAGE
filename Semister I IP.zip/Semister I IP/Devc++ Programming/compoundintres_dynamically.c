#include<math.h>
main()
{
	int p,r,n,t;
	float A;
	printf("enter p:");
	scanf("%d",&p);
	printf("enter r:");
	scanf("%d",&r);
	printf("enter n:");
	scanf("%d",&n);
	printf("enter t:");
	scanf("%d",&t);
	A=p*(pow((1+r/n),(n*t)));
	printf("the compound intrest=%f",A);
}
