#include<stdio.h>
main()
{
	int a,a1,a2,a3;
	printf("enter a:");
	scanf("%d",&a);
	a1=a/365;
	a2=(a-a1*365)/7;
	a3=(a-(a1*365+a2*7))/1;
	printf("\nno.of years=%d,\nno.of weeks=%d,\nno.of days=%d",a1,a2,a3);	
}
