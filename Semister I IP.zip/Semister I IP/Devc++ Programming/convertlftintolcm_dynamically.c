#include<stdio.h>
main()
{
	int lft;
	int lcm;
	printf("enter length in feet:");
	scanf("%d",&lft);
	lcm=(lft*30);
	printf("the result=%d",lcm);
}
