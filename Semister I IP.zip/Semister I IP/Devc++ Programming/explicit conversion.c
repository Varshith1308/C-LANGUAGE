#include<stdio.h>
main()
{
	int m1,m2,m3,m4;
	printf("enter m1,m2,m3,m4:");
	scanf("%d %d %d %d",&m1,&m2,&m3,&m4);
	float result;
	result=(float)(m1+m2+m3+m4)/4;
	printf("m1=%d",m1);
	printf("\nthe result=%f",result);
}
