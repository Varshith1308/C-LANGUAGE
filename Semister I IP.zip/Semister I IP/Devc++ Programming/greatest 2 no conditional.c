#include<stdio.h>
main()
{
	int a,b,D;
	printf("enter a:");
	scanf("%d",&a);
	printf("enter b:");
	scanf("%d",&b);
	D=(a>b)?a:b;
	printf("the result=%d",D);
}
