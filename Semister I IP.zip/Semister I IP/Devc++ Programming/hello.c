/* this is a program to print hello world */
#include<stdio.h>
main()
{
	printf("hello");
}
