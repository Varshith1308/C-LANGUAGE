#include<stdio.h>
main()
{
	int x;
	int y;
	printf("enter x:");
	scanf("%d",&x);	
	printf("the result=%d",y=x<<2);
}
