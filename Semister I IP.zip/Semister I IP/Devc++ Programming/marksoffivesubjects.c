#include<stdio.h>
main()
{
	float m1=45;
	float m2=90;
	float m3=75;
	float m4=35;
	float m5=70;
	float total;
	float average;
	float percentage;
	total=m1+m2+m3+m4+m5;
	average=total/5;
	percentage=(total/500)*100;
	printf("the total=%f,\nthe average=%f,\nthe percentage=%f",total,average,percentage);
}
