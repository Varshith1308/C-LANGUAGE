#include<stdio.h>
main()
{
	int a=5;
	printf("a=%d",a++);
	printf("\na=%d",a);
	printf("\na=%d",++a);
	printf("\na=%d",a++);
	printf("\na=%d",a);
}
