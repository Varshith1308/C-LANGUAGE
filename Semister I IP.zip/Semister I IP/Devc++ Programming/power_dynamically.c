#include<math.h>
main()
{
	float x;
	float y;
	float p;
	printf("enter x value:");
	scanf("%f",&x);
	printf("enter y value:");
	scanf("%f",&y);
	p=pow(x,y);
	printf("the result =%f",p);
}
