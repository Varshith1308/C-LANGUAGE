#include<stdio.h>
main()
{
	int a=2;
	int b=3;
	int c=4;
	float d;
	float x;
	float y;
	d=sqrt(b*b-4*a*c);
	x=(-b+d)/2*a;
	y=(-b-d)/2*a;
	printf("value of x=%f",x);
	printf("\nvalue of y=%f",y);
}
