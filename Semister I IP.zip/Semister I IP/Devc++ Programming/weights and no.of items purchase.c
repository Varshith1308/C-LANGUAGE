#include<stdio.h>
main()
{
	float w1,w2,n1,n2;
	float average;
	printf("enter w1,w2:");
	scanf("%f %f",&w1,&w2);
	printf("enter n1,n2:");
	scanf("%f %f",&n1,&n2);
	average=((w1*n1)+(w2*n2))/(n1+n2);
	printf("the average value of items=%f",average);
}
