#include<stdio.h>
main()
{
	int a[3][3];
	int i,j;
	printf("enter array values:");
	for(i=0;i<3;i++)
	{
	  for(j=0;j<3;j++)
	  {
	  	scanf("%3d",&a[i][j]);
	  }	
   } 
	  for(i=0;i<3;i++)
	  {
	  	for(j=0;j<3;j++)
	  	{
	  		printf("%3d",a[i][j]);
		}
	  printf("\n");
	}
}
