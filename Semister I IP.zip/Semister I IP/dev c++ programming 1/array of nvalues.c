#include<stdio.h>
main()
{
	int a[10],i,n;
	printf("enter n:");
	scanf("%d",&n);
	printf("enter array element:");
	for(i=0;i<n;i++)
	scanf("%d",&a[i]);
	for(i=0;i<n;i++)
	{
		printf("%d\n",a[i]);
	}
}
