#include<stdio.h>
main()
{
	int a[i],i,n,sum=0,avg;
	printf("enter n:");
	scanf("%d",&n);
	printf("enter array element:");
	for(i=0;i<n;i++)
	{
	scanf("%d",&a[i]);
    }
	for(i=0;i<n;i++)
	{
		printf("%d",a[i]);
		sum=sum+a[i];
	}
	printf("\nsum=%d",sum);
	printf("\navg=%d",sum/n);
}
