#include<stdio.h>
main()
{
	int a[100],i,n,pos,k;
	printf("enter n:");
	scanf("%d",&n);
	for(i=0;i<n;i++)
	{
		scanf("%d",&a[i]);
	}
	printf("position of an element:");
	scanf("%d",&pos);
	for(i=pos-1;i<n;i++)
		a[i]=a[i+1];
	for(i=0;i<n-1;i++)
	{
		printf("%3d",a[i]);
	}
}
