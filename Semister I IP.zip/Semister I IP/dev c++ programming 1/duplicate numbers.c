#include<stdio.h>
main()
{
	int a[100],i,n,x,y,d;
	printf("enter n:");
	scanf("%d",&n);
	printf("enter array elements:");
	for(i=0;i<n;i++)
	{
		scanf("%d",&a[i]);
	}	
	for(x=0;x<n;x++)
   {
	for(y=1;y<n-x;y++)
	{
	 if(a[x]==a[x+y])
	 {
	 	d++;
	 }
	}
   }
   printf("duplicate numbers=%d",d);
}
	

