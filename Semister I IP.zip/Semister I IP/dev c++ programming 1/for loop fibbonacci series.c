#include<stdio.h>
main()
{
	int b,i,f1=0,f2=1,sum;
	printf("%d%3d",f1,f2);
	printf("enter b:");
	scanf("%d",&b);
	for(i=1;i<=b;i++)
	{
		sum=f1+f2;
		printf("%3d",sum);
		f1=f2;
		f2=sum;
	}
}
