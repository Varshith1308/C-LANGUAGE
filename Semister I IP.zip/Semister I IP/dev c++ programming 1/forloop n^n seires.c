#include<stdio.h>
#include<math.h>
main()
{
	int sum,n,i;
	printf("enter n:");
	scanf("%d",&n);
	for(sum=0,i=1;i<=n;i++)
	{
		sum=sum+pow(i,i);
	}
	printf("sum=%d",sum);
}
