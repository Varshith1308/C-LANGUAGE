#include<stdio.h>
main()
{
	long long int i=1,fact=1,n;
	printf("enter n value:");
	scanf("%lld",&n);
	for(i=1;i<=n;i++)
	{
		fact=fact*i;
	}
	printf("\n factorial=%lld",fact);
}
