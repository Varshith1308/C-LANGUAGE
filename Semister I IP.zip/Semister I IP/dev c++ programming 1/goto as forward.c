#include<stdio.h>
main()
{
	int i=1,n;
	printf("enter n:");
	scanf("%d",&n);
	goto A;
	i++;
	if(i<=n)
	A:
	printf("%d",i);
	getch();
}
