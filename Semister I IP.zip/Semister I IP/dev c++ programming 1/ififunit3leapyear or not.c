#include<stdio.h>
main()
{
	int year;
	printf("enter the year:");
	scanf("%d",&year);
	if(year%4==0)
	{
		printf("\nleap year");
	}
	if(year%4!=0)
	{
		printf("\nnot a leap year");
	}
	printf("\nhello");
}
