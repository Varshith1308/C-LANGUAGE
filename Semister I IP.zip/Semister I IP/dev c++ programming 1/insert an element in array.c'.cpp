#include<stdio.h>
main()
{
	int a[100],i,n,pos,k;
	printf("enter n:");
	scanf("%d",&n);
	for(i=0;i<n;i++)
	{
		scanf("%d",&a[i]);
	}
	printf("position of an element:");
	scanf("%d",&pos);
	printf("enter element:");
	scanf("%d",&k);
	for(i=n-1;i>=pos;i--)
	{
		a[i+1]=a[i];
		a[pos]=k;
	}
	for(i=0;i<=n;i++)
	{
		printf("%d",a[i]);
	}
}
