#include<stdio.h>
main()
{
	int i=1,sum=0,n;
	float average;
	printf("enter n value:");
	scanf("%d",&n);
	while(i<=n)
	{
		sum=sum+i;
		i++;		
	}
	average=(float)(sum/n);
	printf("sum=%d",sum);
	printf("\naverage=%f",average);
}
