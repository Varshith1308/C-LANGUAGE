#include<stdio.h>
main()
{
	int i=10;
	while(i>=1)
	{
		printf("\ni=%d",i);
		i--;
	}
}
