#include<stdio.h>
main()
{
    int n,rev=0,x;
    printf("enter n value:");
    scanf("%d",&n);
    while(n>0)
    {
    	x=n%10;
    	rev=(rev*10)+x;
    	n=n/10;
	}
	printf("reversed number=%d",rev);
}
