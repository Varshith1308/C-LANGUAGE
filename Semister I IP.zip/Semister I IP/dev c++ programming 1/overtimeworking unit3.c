#include<stdio.h>
main()
{
	int t;
	printf("enter t:");
	scanf("%d",&t);
	if(t<=40)
	{
		printf("salary=%d",t*50);
	}
	else
	{
		printf("salary=%d",((40*50)+((t-40)*62)));
	}
}
