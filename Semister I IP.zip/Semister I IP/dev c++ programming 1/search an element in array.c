#include<stdio.h>
main()
{
	int a[100],n,i,key;
	printf("enter n value:");
	scanf("%d",&n);
	for(i=0;i<n;i++)
	{
		scanf("%d",&a[i]);
	}
	printf("enter key:");
	scanf("%d",&key);
	for(i=0;i<n;i++)
	    {
	      if (a[i]==key)
		 {
			printf("element found");
			break;
		 }
	 }
}
