#include <stdio.h>
main() 
{ 
   int a[100],n, i;
   int large1,large2; 
   printf("enter n value:"); 
   scanf("%d", &n);
   printf("enter elements:"); 
   for(i=0;i<n;i++)
    { 
	  scanf("%d", &a[i]); 
	} 
	 large1=0; 
	 for(i=0;i<n;i++) 
	 { 
	   if(a[i]>large1) 
	   { 
	    large1=a[i];
	   } 
     }
     large2=0; 
	 for(i=0;i<n;i++) 
	 { 
	   if(a[i]>large2 && a[i]<large1) 
	    large2=a[i];
	 }
	 printf("second largest number=%d",large2); 
}
