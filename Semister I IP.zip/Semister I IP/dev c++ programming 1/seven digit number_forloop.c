#include<stdio.h>
main()
{
	int x,i,sum,m;
	int n;
	printf("enter n value:");
	scanf("%d",&n);
	m=n;
    for( ;n>0;n=n/10)
    {
     sum=sum+n%10;
    }
	 m=m%1000;
	 m=m/100;
	 sum=sum-m;
	 m=m*m*m;
	if(m==sum)
	{
    	printf("VALID");
	}
	else
	{
		printf("NOT VALID");
	}
}
