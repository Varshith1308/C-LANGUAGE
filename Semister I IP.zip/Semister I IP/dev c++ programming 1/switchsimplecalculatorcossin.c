#include<stdio.h>
#include<math.h>
main()
{
	int a,b,result;
	char ch;
	printf("1 for addition");
	printf("\n 2 for subtraction");
	printf("\n 3 for multiplication");
	printf("\n 4 for division");
	printf("\n 5 for modulo division");
    printf("\n 6 for square root");
    printf("\n 7 for power");
	printf("\n 8 for sin");
	printf("\n 9 for cos");
	printf("\n enter character:");
	scanf("%c",&ch);
	printf("enter the values:");
	scanf("%d%d",&a,&b);
	switch(ch)
	{
		case 1:result=a+b;
		       printf("\n result=%d",result);
		       break;
		case 2:result=a-b;
		       printf("\n result=%d",result);
		       break;
		case 3:result=a*b;
		       printf("\n result=%d",result);  
		       break;
		case 4:result=a/b;
		       printf("\n result=%d",result);     
		       break;
		case 5:result=a%b;
		       printf("\n result=%d",result);
		       break;
		case 6:result=sqrt(a);
	           printf("\n result=%d",result);
	           result=sqrt(b);
		       printf("\n  result=%d",result);
               break;
		case 7:result=pow(a,b);
	           printf("\n result=%d",result);	
			   break;		          
		case 8:result=sin(a);
		       printf("\n result=%d",result);
			   result=sin(b);
			   printf("\n result=%d",result);	
			   break;	 
		case 9:result=cos(a);
		       printf("\n result=%d",result);
			   result=cos(b);					 	
		       printf("\n result=%d",result);	
			   break;						 			         
	}
}
