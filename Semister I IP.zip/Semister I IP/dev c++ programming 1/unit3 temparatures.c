#include<stdio.h>
main()
{
	int t;
	printf("enter temparature:");
	scanf("%d",&t);
	if(t<0)
	{
		printf("freezing weather");
	}
	else if(t>=0&&t<10)
	{
		printf("very cold weather");
	}
    else if(t>=10&&t<20)
    {
    	printf("cold weather");
	}
	else if(t>=20&&t<30)
	{
		printf("normal in temp");
	}
	else if(t>=30&&t<40)
	{
		printf("its hot");
	}
	else
	{
	    printf("its very hot");	
    } 
}
