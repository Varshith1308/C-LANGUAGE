#include<stdio.h>
main()
{ 
    int p, q, r, s; 
	printf("enter p: "); 
	scanf("%d", &p); 
	printf("enter q: "); 
	scanf("%d", &q); 
	printf("enter s: "); 
	scanf("%d", &s);
	printf("enter r : "); 
	scanf("%d", &r); 
	if(q > r && s > p && ((r+s) > (p+q)) && (r > 0) && (s > 0) && (p%2 == 0)) 
	{ 
	     printf("correct values");
    } 
	else 
	{ 
	    printf("wrong values"); 
	}
}
