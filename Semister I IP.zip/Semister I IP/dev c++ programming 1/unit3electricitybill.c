#include<stdio.h>
main()
{
  float charge,u,n;
  printf("enter the units of electricity consumed:");
  scanf("%f",&u);
  printf("enter consumer name:");
  scanf("%f",&n);
  if(u<=200)
  {
  	charge=(0.80*u)+100;
  	if(charge<=100)
  	{
  		printf("charge=%f,charge");
    }
 }
 else if(u>=200&&u<=300)
 {
 	float unit1=u-200;
 	charge=(0.8*200)+(0.9*unit1)+100;
 	printf("charge=%f",charge);	
 }
 else
 {
 	float charge=1*u;
 	if(charge>=400)
 	{
 		float charge2=(0.15*charge)+charge+100;
 		printf("charge=%f",charge2);
	 }
  }
}
