#include<stdio.h>
main()
{
	int a;
	printf("enter a value:");
	scanf("%d",&a);
	if(a%2==0)
	{
		printf("even number");
	}
	if(a%2!=0)
	{
		printf("\nodd number");
	}
	printf("\nhello");
}
