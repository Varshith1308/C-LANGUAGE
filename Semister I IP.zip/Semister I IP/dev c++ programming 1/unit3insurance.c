#include<stdio.h>
main()
{
	float age,gender,health,resides;
	float amount;
	printf("Enter amount\n");
	scanf("%f",&amount);
	printf("enter age\nenter gender(1 if male 0 if female)\nhealth(1 if healthy 0 if unhealthy)\n" );
	scanf("%f%f%f",&age,&gender,&health);
	printf("enter 1 if living in city and 0 if lives in village\n");
	scanf("%f",&resides);
	float amount1=amount/1000;
	if((age>=25&&age<=35)&&(health==1)&&(resides==1))
	{
		if(gender==1)
		{
		  float insu=(4*amount1)+amount;
		  if(insu<=200000)
		  {
		     printf("Insurance amount is %f",insu);
          }
          else
          {
          	 printf("No insurance amount");
		  }
		}
		else
		{
		  float insu=(3*amount1)+amount;
		  if(insu<=100000)
		  {
		    printf("Insurence amount is %f",insu);
          }
          else
          {
          	printf("No insurance amount");
		  }	
		}
	}
	else if((health==0)&&(age>=25&&age<=35)&&(resides==0))
	{
		if(gender==1)
		{
			float insu=(6*amount1)+amount;
			if(insu<10000)
			{
			  printf("Insurance amount is %f",insu);
	    	}
	    	else
		    {
		      printf("No insurance amount");
		    }
		}
		else
		{
			printf("No insurance amount");
		}
	}
	else
	{
		printf("No insurance amount");
	}
}
