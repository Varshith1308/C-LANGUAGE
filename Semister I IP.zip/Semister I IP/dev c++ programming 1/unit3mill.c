#include<stdio.h>
main()
{
	float amount;
	float cloth;
	printf("enter the amount:");
	scanf("%f",&amount);
	printf("enter type of cloth\n1 if mill\n 2 if handloom\n");
	scanf("%f",&cloth);
	if(amount<=100)
	{
		if(cloth==1)
		{
			printf("amount=%f",amount);
		}
		else
		{
			printf("amount=%f",amount+(0.05*amount));
		}
	}
	else if(amount>100&&amount<=200)
	{
		if(cloth==1)
		{
			printf("amount=%f",amount+(0.05*amount));
		}
		else
		{
			printf("amount=%f",amount+(0.75*amount));
		}
    }  
	else if(amount>200&&amount<=300)
    {
        if(cloth==1)
		{
			printf("amount=%f",amount+(0.75*amount));
		}
		else
		{
			printf("amount=%f",amount+(0.1*amount));
		}
   }
    else 
   {
        if(cloth==1)
        {
            printf("amount=%f",amount+(0.1*amount));
		}
		else
		{
			printf("amount=%f",amount+(0.15*amount));
		}
	}
}
