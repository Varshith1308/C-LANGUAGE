#include<stdio.h>
main()
{
	int m,p,c;
	printf("enter maths marks:");
	scanf("%d",&m);
	printf("enter phy marks:");
	scanf("%d",&p);
	printf("enter che marks:");
	scanf("%d",&c);
	if(m>=65&&p>=55&&c>=50&&(m+p+c)>=180||(m+p)>=140)
	{
		printf("eligible");
	}
	else
	{
		printf("not eligible");
	}
}
