#include<stdio.h>
main() 
{ 
	float s; 
	char g; 
	printf("enter salary and gender:");
	scanf("%d%c",&s,&g);
	if(g=='m')
	{
		float bonus=(0.05)*s;
		printf("salary=%f",bonus+s);
	}
	else
	{
		float bonus1=(0.1)*s;
		printf("salary=%f",bonus1+s);
	}
}
