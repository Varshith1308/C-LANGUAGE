#include<stdio.h>
main()
{
	int i=1,n;
	printf("enter n:");
	scanf("%d",&n);
	A:
	    printf("%d*%d=%d\n",n,i,n*i);
		i++;
		if(i<=10)
		goto A;
		printf("\n End of program");
		getch();	
}
